﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            //capturar valores da tela 
            float valorpago = float.Parse(txtvalorpago.Text);
            float gasolina = float.Parse(txtgasolina.Text);
            float qntlitros;

            //calculo
            qntlitros = valorpago / gasolina;

            //mostrar resultado
            MessageBox.Show("a quantidade de litros foi: " + qntlitros);
        }
    }
}
